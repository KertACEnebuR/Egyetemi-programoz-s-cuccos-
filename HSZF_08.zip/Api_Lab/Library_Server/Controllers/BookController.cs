﻿using Library_Server.Data;
using Library_Server.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Library_Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly LibraryDbContext _db;

        public BookController(LibraryDbContext context) 
        {
            this._db = context;
        }

        public async Task<ActionResult> GetBooksAction()
        {
            var result = await _db.Books.Include(a => a.Author).ToListAsync();
            return Ok(result);
        }

        [HttpGet]
        public async Task<List<Book>> GetBooks()
        {
            return await _db.Books.Include(a => a.Author).ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Book>> GetBookById(int id)
        {
            var book = await _db.Books.FirstOrDefaultAsync(i => i.Id == id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        [HttpPost]
        public async Task<ActionResult<Book>> CreateBook([FromBody] Book newBook)
        {
            
            var book = await _db.Books.FirstOrDefaultAsync(x => x.Id == newBook.Id);
            if (book != null)
            {
                return BadRequest("Duplicated key!");
            }

            var author = await _db.Authors.FirstOrDefaultAsync(x => x.Id == newBook.AuthorId);
            if (author == null)
            {
                return BadRequest("Not valid author!");
            }

            newBook.Author = author;
            this._db.Books.Add(newBook);
            await _db.SaveChangesAsync();
            return Ok(newBook);

        }
    }
}
