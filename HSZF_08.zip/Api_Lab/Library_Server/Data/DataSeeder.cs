﻿using Library_Server.Data.Entities;

namespace Library_Server.Data
{
    public static class DataSeeder
    {
        public static void Seed(LibraryDbContext context)
        {
            if (context.Authors.Count() > 0)
            {
                return;
            }
            else
            {
                context.Authors.AddRange(
                    new Author { 
                        Name = "J.K Rowling", 
                        Books = {
                            new Book
                            {
                            Title = "A book",
                            Year = 2000
                            },
                            new Book
                            {
                            Title = "B book",
                            Year = 2005
                            }
                        }    
                    },
                    new Author
                    {
                        Name = "J.R.R Tolkien",
                        Books = {
                            new Book
                            {
                            Title = "C book",
                            Year = 2010
                            },
                            new Book
                            {
                            Title = "D book",
                            Year = 2010
                            }
                        }
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
