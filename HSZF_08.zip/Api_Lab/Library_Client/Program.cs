﻿using Library_Client.Models;
using System;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace MyApp
{
    internal class Program
    {
        private const string path = "localhost";
        private const string port = "5055";
        private Uri uri = new Uri($"http://{path}:{port}");

        private HttpClient client;
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Init();
            Console.ReadLine();
        }

        public async Task Init()
        {
            Console.WriteLine("Start!");
            Console.ReadLine();
            client = new HttpClient()
            {
                BaseAddress = uri
            };
            var books = await client.GetFromJsonAsync<List<Book>>("api/book");
            foreach (var item in books)
            {
                Console.WriteLine(item.Title);
            }
            Console.WriteLine("------------------------------");

            var newBook = new Book()
            {
                AuthorId = books[0].AuthorId,
                Title = "Minta",

            };

            var response = await client.PostAsJsonAsync<Book>("api/book", newBook);
            if (response != null)
            {
                if (response.IsSuccessStatusCode)
                {
                    books = await client.GetFromJsonAsync<List<Book>>("api/book");
                    foreach (var item in books)
                    {
                        Console.WriteLine(item.Title);
                    }
                }
            }

        }
    }
}