﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320
{
    class Program
    {
        static void Main(string[] args)
        {
            long n = (1 << 61) - 1;
            Console.WriteLine(new PrimeTools(n).IsPrime());
        }
    }
}
