﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320
{
    public class PrimeTools
    {
        long number;

        public PrimeTools(long number)
        {
            this.number = number;
        }

        public bool IsPrime()
        {
            if (number < 2)
            {
                return false;
            }
            for (long i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
