using NUnit.Framework;
using System;
using SZFA0320;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [TestCase(4, false)]
        [TestCase(8, false)]
        [TestCase(30, false)]
        [TestCase(0, false)]
        [TestCase(2, true)]
        [TestCase(20000, false)]
        [TestCase(999999999999999998, false)]
        [TestCase((1L << 61) - 1, true)]

        public void Test_PrimeTools_EvenNumbers(long input, bool expected)
        {
            //Arrange
            PrimeTools primeTools = new PrimeTools(input);

            //Act
            bool actual = primeTools.IsPrime();

            //Assert
            Assert.That(actual, Is.EqualTo(expected));
        }

        [TestCase(1, false)]
        [TestCase(3, true)]
        [TestCase(5, true)]
        [TestCase(25, false)]
        [TestCase(67, true)]

        public void Test_PrimeTools_OddNumbers(long input, bool expected)
        {
            //Arrange
            PrimeTools primeTools = new PrimeTools(input);

            //Act
            bool actual = primeTools.IsPrime();

            //Assert
            Assert.That(actual, Is.EqualTo(expected));
        }

        [TestCase(-1, false)]
        [TestCase(-2, false)]
        [TestCase(-3, false)]
        [TestCase(-67, false)]
        [TestCase(-100, false)]

        public void Test_PrimeTools_NegativeNumbers(long input, bool expected)
        {
            //Arrange
            PrimeTools primeTools = new PrimeTools(input);

            //Act
            bool actual = primeTools.IsPrime();

            //Assert
            Assert.That(actual, Is.EqualTo(expected));
        }
    }
}