﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SzFA1
{
    class Cage
    {
        Animal[] animals;
        int count;

        public Cage(int capacity)
        {
            animals = new Animal[capacity];
        }

        public bool Add(Animal a)
        {
            if (count < animals.Length)
            {
                animals[count++] = a;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Delete(string name)
        {
            int idx = 0;
            for (int i = 0; i < count; i++)
            {
                if (animals[i].Name == name)
                {
                    idx = i;
                }
            }
        }
    }
}
