﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SzFA1
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal a = new Animal();
        }
    }
}
