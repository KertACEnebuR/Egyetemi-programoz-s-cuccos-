﻿namespace SzFA1
{
    internal class Enums
    {
        public enum SpeciesType { Dog, Panda, Rabbit }
    }
}
