﻿using static SzFA1.Enums;

namespace SzFA1
{

    internal class Animal
    {
        string name;
        bool gender;
        int weight;
        SpeciesType species;

        public string Name { get; internal set; }

        public Animal(string name, bool gender, int weight, SpeciesType species)
        {
            this.name = name;
            this.gender = gender;
            this.weight = weight;
            this.species = species;
        }

        public Animal(string name) : this(name, false, 10, SpeciesType.Dog)
        {

        }

    }
}
