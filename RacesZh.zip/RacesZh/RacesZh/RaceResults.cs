﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RacesZh
{
    public class RaceResults
    {
        RunnerWithTime[] Result;

        public RaceResults(int runnersCount, string[] inputs)
        {
            Result = new RunnerWithTime[runnersCount];
            for (int i = 0; i < runnersCount; i++)
            {
                Result[i] = RunnerWithTime.Parse(inputs[i]);
            }

            if (!IsSorted())
            {
                Sort();
            }
        }

        private bool IsSorted()
        {
            for (int i = 0; i < Result.Length - 1; i++)
            {
                if (Result[i].CompareTo(Result[i + 1]) > 0)
                {
                    return false;
                }
            }
            return true;
        }

        private void Sort()
        {
            // Javított beillesztéses rendezés
            for (int i = 1; i < Result.Length; i++)
            {
                RunnerWithTime current = Result[i];

                int j = i - 1;

                while (j >= 0 && Result[j].CompareTo(current) > 0)
                {
                    Result[j + 1] = Result[j];
                    j--;
                }

                Result[j + 1] = current;
            }
        }

        private int LowerBound(Time time)
        {
            int left = 0;
            int right = Result.Length - 1;
            int center = (left + right) / 2;
            while (left <= right)
            {
                if (Result[center].Result.CompareTo(time) < 0)
                {
                    left = center + 1;
                }
                if (Result[center].Result.CompareTo(time) > 0)
                {
                    right = center - 1;
                }
            }
            return left;
        }

        private int UpperBound(Time time)
        {
            int left = 0;
            int right = Result.Length - 1;
            int center = (left + right) / 2;
            while (left <= right)
            {
                if (Result[center].Result.CompareTo(time) <= 0)
                {
                    left = center + 1;
                }
                if (Result[center].Result.CompareTo(time) >= 0)
                {
                    right = center - 1;
                }
            }
            return left;
        }

        public RunnerWithTime[] Between(Time lower, Time upper)
        {
            int from = LowerBound(lower);
            int to = UpperBound(upper);

            RunnerWithTime[] result = new RunnerWithTime[to - from];

            for (int i = from; i < to; i++)
            {
                result[i - from] = Result[i];
            }

            return result;
        }

        public bool Contains(Predicate<RunnerWithTime> predicate, out RunnerWithTime runnerPerformance)
        {
            foreach (RunnerWithTime runner in Result)
            {
                if (predicate(runner))
                {
                    runnerPerformance = runner;
                    return true;
                }
            }

            runnerPerformance = null;
            return false;
        }


        private int BinarySearch(RunnerWithTime value)
        {
            int left = 0;
            int right = Result.Length - 1;
            int center = (left + right) / 2;
            while (left <= right)
            {

                if (Result[center].CompareTo(value) == 0)
                {
                    return center;
                }
                if (Result[center].CompareTo(value) < 0)
                {
                    left = center + 1;
                }
                if (Result[center].CompareTo(value) > 0)
                {
                    right = center - 1;
                }
            }
            return -1;
        }

        public int[] Intersection(int[] a, int[] b)
        {
            int i = 0;
            int j = 0;
            List<int> bothresult = new List<int>();

            while (a.Length > i && b.Length > j)
            {
                if (a[i].CompareTo(b[j]) == 0)
                {
                    i++;
                    j++;
                    bothresult.Add(a[i]);
                }
                if (a[i].CompareTo(b[j]) > 0)
                {
                    j++;
                }
                if (a[i].CompareTo(b[j]) < 0)
                {
                    i++;
                }
            }
           
            int[] result = bothresult.ToArray();
            return result;
        }
    }
}
