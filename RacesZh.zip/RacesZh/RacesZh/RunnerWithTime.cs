﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RacesZh
{
    public class RunnerWithTime: IComparable<RunnerWithTime>
    {
        public string Name { get; private set; }
        public Time Result { get; private set; }

        public static RunnerWithTime Parse(string input)
        {
            string[] temp = input.Split(',');
            string name = temp[0];
            Time result = Time.Parse(temp[1]);
            RunnerWithTime runnertime = new RunnerWithTime();
            runnertime.Name = name;
            runnertime.Result = result;
            return runnertime;
        }

        public int CompareTo(RunnerWithTime other)
        {
            if (this.Result.Equals(other.Result))
            {
                return this.Name.CompareTo(other.Name);
            }
            return this.Result.CompareTo(other.Result);
        }

        public override string ToString()
        {
            return $"{Name} ({Result})";
        }

        public override bool Equals(object? obj)
        {
            if (obj is null)
            {
                throw new ArgumentNullException();
            }
            if (!(obj is RunnerWithTime))
            {
                throw new ArgumentException();
            }
            RunnerWithTime other = obj as RunnerWithTime;
            return this.Name.Equals(other.Name) && this.Result.Equals(other.Result);
        }
    }
}
