﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RacesZh
{
    public class Races
    {
        public RaceResults[] RaceResults { get; private set; }

        public Races(RaceResults[] raceResults)
        {
            RaceResults = raceResults;
        }

        public Time BestPerformance(string name)
        {
            Time best = null;

            foreach (RaceResults race in RaceResults)
            {
                if (race.Contains(
                    r => r.Name == name,
                    out RunnerWithTime runner))
                {
                    if (best == null ||
                        runner.Result.CompareTo(best) < 0)
                    {
                        best = runner.Result;
                    }
                }
            }

            return best;
        }

        private RunnerWithTime[] Union(
       RunnerWithTime[] first,
       RunnerWithTime[] second)
        {
            RunnerWithTime[] result =
                new RunnerWithTime[first.Length + second.Length];

            int i = 0;
            int j = 0;
            int k = 0;

            while (i < first.Length && j < second.Length)
            {
                if (first[i].CompareTo(second[j]) <= 0)
                {
                    result[k++] = first[i++];
                }
                else
                {
                    result[k++] = second[j++];
                }
            }

            while (i < first.Length)
                result[k++] = first[i++];

            while (j < second.Length)
                result[k++] = second[j++];

            return result;
        }

        public RunnerWithTime[] AllBetween(Time lower, Time upper)
        {
            RunnerWithTime[] result = Array.Empty<RunnerWithTime>();

            foreach (RaceResults race in RaceResults)
            {
                result = Union(
                    result,
                    race.Between(lower, upper)
                );
            }

            return result;
        }
    }
}
