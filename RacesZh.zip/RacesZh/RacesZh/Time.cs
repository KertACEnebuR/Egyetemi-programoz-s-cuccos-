﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RacesZh
{
    public class Time : IComparable<Time>
    {
        int Hour;
        int Minute;
        int Second;

        public int Hours {
            get { return Hour; }
            set {
                int min = 0;
                int max = 3;
                if (value > max || min > value)
                {
                    throw new TimeException("0 es 3 kozott kell lennie!");
                }            
            }

        }
        public int Minutes
        {
            get { return Minute; }
            set
            {
                int min = 0;
                int max = 59;
                if (value > max || min > value)
                {
                    throw new TimeException("0 es 59 kozott kell lennie!");
                }
            }

        }
        public int Seconds
        {
            get { return Second; }
            set
            {
                int min = 0;
                int max = 59;
                if (value > max || min > value)
                {
                    throw new TimeException("0 es 59 kozott kell lennie!");
                }
            }
        }

        public Time(int hour, int minute, int second)
        {
            Hour = hour;
            Minute = minute;
            Second = second;
        }

        public Time(int minute, int second) : this(0, minute, second)
        {

        }

        public override string ToString()
        {
            if (Hour == 0)
            {
                return $"{Minute.ToString("00")}:{Second.ToString("00")}";
            }
            else
            {
                return $"{Hour.ToString("00")}:{Minute.ToString("00")}:{Second.ToString("00")}";
            }
        }

        public static Time Parse(string input)
        {
            string[] temp = input.Split(':');
            if (temp.Length == 2)
            {
                int minutes = int.Parse(temp[0]);
                int seconds = int.Parse(temp[1]);
                 return new Time(minutes, seconds);
            }
            else if (temp.Length == 3)
            {
                int hours = int.Parse(temp[0]);
                int minutes = int.Parse(temp[1]);
                int seconds = int.Parse(temp[2]);
                return new Time(hours, minutes, seconds);
            }
            throw new TimeException("Nem jo a formatum");
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                throw new ArgumentNullException();
            }
            if (!(obj is Time))
            {
                throw new ArgumentException();
            }
            Time other = obj as Time;
            return this.Hour == other.Hour && this.Minutes == other.Minute && this.Second == other.Second;
        }

        public int CompareTo(Time other)
        {
            int Thisresult = this.Hour * 3600 + this.Minute * 60 + this.Second;
            int Otherresult = other.Hour * 3600 + other.Minute * 60 + other.Second;
            return Thisresult.CompareTo(Otherresult);
        }
    }
}
