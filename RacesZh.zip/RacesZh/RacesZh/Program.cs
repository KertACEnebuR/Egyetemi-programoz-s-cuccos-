﻿using RacesZh;
using System;

namespace MyApp
{
    internal class Program
    {
        public static string[] ReadFile(string path)
        {
            string[] fileLines = File.ReadAllLines(path);

            int count = int.Parse(fileLines[0]);

            string[] result = new string[count];

            for (int i = 0; i < count; i++)
            {
                result[i] = fileLines[i + 1];
            }

            return result;
        }

        public static Races ReadFolder(string path)
        {
            string[] files = Directory.GetFiles(path, "*.txt");

            RaceResults[] races = new RaceResults[files.Length];

            for (int i = 0; i < files.Length; i++)
            {
                string[] data = ReadFile(files[i]);

                races[i] = new RaceResults(data.Length, data);
            }

            return new Races(races);
        }

        static void Main(string[] args)
        {
            string folderPath = @"C:\Versenyek"; // Itt add meg a könyvtárat
            var races = ReadFolder(folderPath);

            // Kérjük be a futó nevét
            Console.Write("Add meg a futó nevét: ");
            string name = Console.ReadLine();

            var best = races.BestPerformance(name);
            if (best != null)
            {
                Console.WriteLine($"{name} legjobb ideje: {best}");
            }
            else
            {
                Console.WriteLine($"{name} még nem vett részt egy versenyen sem.");
            }

            // Félmaraton 01:45:00 és 02:00:00 között
            var lower = new Time(1, 45, 0);
            var upper = new Time(2, 0, 0);
            var results = races.AllBetween(lower, upper);

            Console.WriteLine("\nFélmaraton 01:45:00 és 02:00:00 között teljesítők:");
            foreach (var runner in results)
            {
                Console.WriteLine(runner);
            }
        }
    }
}
