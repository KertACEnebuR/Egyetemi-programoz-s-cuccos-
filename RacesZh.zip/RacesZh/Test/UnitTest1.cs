using RacesZh;
namespace Test
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        // Parse met�dus tesztel�se � �rv�nyes form�tumok
        [TestCase("57:38", 0, 57, 38)]
        [TestCase("59:59", 0, 59, 59)]
        [TestCase("00:00", 0, 0, 0)]
        [TestCase("01:56:17", 1, 56, 17)]
        [TestCase("03:00:00", 3, 0, 0)]
        public void Parse_ValidFormat_ReturnsCorrectTime(string input, int expectedHours, int expectedMinutes, int expectedSeconds)
        {
            // Act
            Time result = Time.Parse(input);

            // Assert
            Assert.AreEqual(expectedHours, result.Hours);
            Assert.AreEqual(expectedMinutes, result.Minutes);
            Assert.AreEqual(expectedSeconds, result.Seconds);
        }

        // Parse met�dus tesztel�se � �rv�nytelen form�tumok
        [TestCase("")]
        [TestCase("invalid")]
        [TestCase("12")]
        [TestCase("12:60:00")]
        [TestCase("99:99")]
        [TestCase("01:99:99")]
        [TestCase("04:00:00")]
        [TestCase("01:99")]
        public void Parse_InvalidFormat_ThrowsTimeException(string input)
        {
            // Act & Assert
            Assert.Throws<TimeException>(() => Time.Parse(input));
        }

        [Test]

        public void CompareTo_Equals_ReturnsZero()
        {
            Time time1 = new Time(1, 30, 0);
            Time time2 = new Time(1, 30, 0);

            Assert.AreEqual(0, time1.CompareTo(time2));
        }

        [Test]

        public void CompareTo_FirstSmaller_ReturnsNegative()
        {
            Time time1 = new Time(1, 15, 0);
            Time time2 = new Time(1, 30, 0);

            int result = time1.CompareTo(time2);
            Assert.IsTrue(0 > result);
        }

        [Test]

        public void CompareTo_SecondSmaller_ReturnsPositive()
        {
            Time time1 = new Time(1, 45, 0);
            Time time2 = new Time(1, 30, 0);

            int result = time1.CompareTo(time2);
            Assert.IsTrue(result > 0);
        }

        [TestCase(0, 57, 38, "57:38")]
        [TestCase(0, 59, 59, "59:59")]
        [TestCase(0, 0, 0, "00:00")]
        [TestCase(1, 56, 17, "01:56:17")]
        [TestCase(3, 0, 0, "03:00:00")]
        public void Test_ToString_Format(int hours, int minutes, int seconds, string expected)
        {
            Time time = new Time(hours, minutes, seconds);

            string result = time.ToString();

            Assert.AreEqual(result, expected);
        }

        //EQUALS

        public void Equals_same()
        {
            Time time1 = new Time(1, 30, 45);
            Time time2 = new Time(1, 30, 45);

            Assert.IsTrue(time1.Equals(time2));
        }

        public void Equals_different()
        {
            Time time1 = new Time(1, 30, 45);
            Time time2 = new Time(1, 0, 45);

            Assert.IsFalse(time1.Equals(time2));
        }

        [TestCase(-1, 30, 30)]
        [TestCase(4, 0, 0)]
        [TestCase(1, -1, 0)]
        [TestCase(1, 60, 0)]
        [TestCase(1, 30, -1)]
        [TestCase(1, 30, 60)]
        public void Constructor_InvalidValues_ThrowsTimeException(int hours, int minutes, int seconds)
        {
            // Act & Assert
            Assert.Throws<TimeException>(() => new Time(hours, minutes, seconds));
        }


        [TestFixture]
        public class RaceResultsTests
        {
            [Test]
            public void Between_ReturnsCorrectRange()
            {
                // Arrange
                string[] inputs = new string[]
                {
                "Anna, 55:00",
                "Bela, 58:30",
                "Csaba, 01:02:15",
                "David, 01:05:45",
                "Eva, 01:10:00"
                };
                RaceResults results = new RaceResults(5, inputs);
                Time lower = new Time(57, 0);      // 57:00
                Time upper = new Time(1, 3, 0);    // 01:03:00

                // Act
                RunnerWithTime[] between = results.Between(lower, upper);

                // Assert
                Assert.AreEqual(2, between.Length);
                Assert.AreEqual("Bela", between[0].Name);
                Assert.AreEqual("Csaba", between[1].Name);
            }

            [Test]
            public void Between_NoResults_ReturnsEmptyArray()
            {
                // Arrange
                string[] inputs = new string[]
                {
                "Anna, 55:00",
                "Bela, 58:30"
                };
                RaceResults results = new RaceResults(2, inputs);
                Time lower = new Time(2, 0, 0);
                Time upper = new Time(3, 0, 0);

                // Act
                RunnerWithTime[] between = results.Between(lower, upper);

                // Assert
                Assert.AreEqual(0, between.Length);
            }

            [Test]
            public void Between_ExactLowerBound_IncludesLower()
            {
                // Arrange
                string[] inputs = new string[]
                {
                "Anna, 55:00",
                "Bela, 57:00",
                "Csaba, 58:00"
                };
                RaceResults results = new RaceResults(3, inputs);
                Time lower = new Time(57, 0);
                Time upper = new Time(59, 0);

                // Act
                RunnerWithTime[] between = results.Between(lower, upper);

                // Assert
                Assert.AreEqual(2, between.Length);
                Assert.AreEqual("Bela", between[0].Name);
            }

            [Test]
            public void Contains_ExistingRunner_ReturnsTrueAndRunner()
            {
                // Arrange
                string[] inputs = new string[]
                {
                "Anna, 55:00",
                "Bela, 58:30"
                };
                RaceResults results = new RaceResults(2, inputs);

                // Act
                bool contains = results.Contains(r => r.Name == "Anna", out RunnerWithTime runner);

                // Assert
                Assert.IsTrue(contains);
                Assert.IsNotNull(runner);
                Assert.AreEqual("Anna", runner.Name);
            }

            [Test]
            public void Contains_NonExistingRunner_ReturnsFalseAndNull()
            {
                // Arrange
                string[] inputs = new string[]
                {
                "Anna, 55:00",
                "Bela, 58:30"
                };
                RaceResults results = new RaceResults(2, inputs);

                // Act
                bool contains = results.Contains(r => r.Name == "Csaba", out RunnerWithTime runner);

                // Assert
                Assert.IsFalse(contains);
                Assert.IsNull(runner);
            }



            //[TestFixture]
            //public class RunnerWithTimeTests
            //{
            //    [Test]
            //    public void CompareTo_SameTimeAndName_ReturnsZero()
            //    {
            //        RunnerWithTime r1 = new RunnerWithTime("Anna", new Time(1, 30, 0));
            //        RunnerWithTime r2 = new RunnerWithTime("Anna", new Time(1, 30, 0));

            //        int result = r1.CompareTo(r2);

            //        Assert.AreEqual(0, result);
            //    }

            //    [Test]
            //    public void CompareTo_SameTimeDifferentName_CompareByName()
            //    {
            //        RunnerWithTime r1 = new RunnerWithTime("Anna", new Time(1, 30, 0));
            //        RunnerWithTime r2 = new RunnerWithTime("Bela", new Time(1, 30, 0));

            //        int result = r1.CompareTo(r2);

            //        Assert.IsTrue(result < 0); // "Anna" < "Bela"
            //    }

            //    [Test]
            //    public void CompareTo_DifferentTime_CompareByTime()
            //    {
            //        RunnerWithTime r1 = new RunnerWithTime("Bela", new Time(1, 15, 0)); // jobb id�
            //        RunnerWithTime r2 = new RunnerWithTime("Anna", new Time(1, 30, 0)); // rosszabb id�

            //        int result = r1.CompareTo(r2);

            //        Assert.IsTrue(result < 0); // jobb id� = kisebb
            //    }

            //    [Test]
            //    public void CompareTo_NullObject_ThrowsArgumentException()
            //    {
            //        RunnerWithTime r1 = new RunnerWithTime("Anna", new Time(1, 30, 0));

            //        Assert.Throws<ArgumentException>(() => r1.CompareTo(null));
            //    }
            //}
        }
    }
}