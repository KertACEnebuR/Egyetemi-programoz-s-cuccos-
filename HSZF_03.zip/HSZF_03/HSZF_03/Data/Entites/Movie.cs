﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSZF_03.Data.Entites
{
    public class Movie
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(450)]
        public string Title { get; set; }

        public int Minutes { get; set; }

        public DateTime ReleaseDate { get; set; }

        public int DirectorId { get; set; } //FK
        public virtual Director Director { get; set; } //navigacios property

        public virtual ICollection<Role> Roles { get; set; }

        public override string ToString()
        {
            return this.Title;
        }
    }
}
