﻿using HSZF_03.Data.Entites;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSZF_03.Data
{
    public class MovieDatabaseContext : DbContext
    {
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Actor> Actors { get; set; }
        public DbSet<Director> Directors { get; set; }
        public DbSet<Role> Roles { get; set; }

        public MovieDatabaseContext()
        {
            this.Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var path = Path
                    .Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "MovieDb.mdf");
                optionsBuilder
                    //.UseSqlServer($@"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename={path};Integrated Security=True");
                    .UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\source\\repos\\HSZF_03\\HSZF_03\\Data\\MovieDb.mdf;Integrated Security=True");
                optionsBuilder.UseLazyLoadingProxies();
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Movie>()
            //    .HasOne(x => x.Director)
            //    .WithMany(x => x.Movies)
            //    .HasForeignKey(x => x.DirectorId)
            //    .OnDelete(DeleteBehavior.Cascade);

            //modelBuilder.Entity<Role>()
            //    .HasOne(x => x.Actor)
            //    .WithMany(x => x.Roles)
            //    .HasForeignKey(x => x.ActorId)
            //    .OnDelete(DeleteBehavior.NoAction);

            //modelBuilder.Entity<Movie>()
            //    .HasMany(x => x.Roles)
            //    .WithOne(x => x.Movie)
            //    .HasForeignKey(x => x.MovieId)
            //    .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<Actor>()
                .HasMany(x => x.Roles)
                .WithOne(x => x.Actor)
                .HasForeignKey(x => x.ActorId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Role>()
                .HasOne(x => x.Movie)
                .WithMany(x => x.Roles)
                .HasForeignKey(x => x.MovieId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Director>()
                .HasMany(x => x.Movies)
                .WithOne(x => x.Director)
                .HasForeignKey(x => x.DirectorId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
