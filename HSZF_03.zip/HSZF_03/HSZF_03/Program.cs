﻿// See https://aka.ms/new-console-template for more information
using HSZF_03.Data;
using System;
using HSZF_03.Data.Entites;
using Microsoft.EntityFrameworkCore;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //List<int> ints = new List<int>();
            //List<int> ints1 = new List<int>();
            //ints.Add(1);
            //ints.Add(2);
            //ints.Add(3);
            //ints.Add(4);

            //for (int i = 0; i < ints.Count; i++)
            //{
            //    Console.WriteLine(string.Join(", ", ints.GetRange(0, i)));
            //    Console.WriteLine();
            //}

            //Console.WriteLine("----------------------------");
            
            //for (int i = 0; i < ints.Count; i++) 
            //{
            //    ints1.AddRange(ints.Where(x => x < i).ToList());
            //}

            MovieDatabaseContext context = new MovieDatabaseContext();

            var actor = new Actor() { Name = "Sanyi" };
            context.SaveChanges();

            var dir = new Director() { Name = "Béla" };
            context.Directors.Add(dir);
            context.SaveChanges();

            var movie = new Movie() { Title = "Dune", Minutes = 200, ReleaseDate = DateTime.Now, Director = dir, DirectorId = dir.Id };
            context.Movies.Add(movie);
            context.SaveChanges();

            var role = new Role() { Actor = actor, Movie = movie, CharacterName = "Boss" };
            context.Roles.Add(role);
            context.SaveChanges();

            var movie1 = new Movie() { Title = "Dune 2", Minutes = 200, ReleaseDate = DateTime.Now, Director = context.Directors.First() };
            context.Movies.Add(movie1);
            context.SaveChanges();

            var role1 = new Role() { Actor = context.Actors.First(), Movie = movie, CharacterName = "BOSS" };
            context.Roles.Add(role1);
            context.SaveChanges();
            
            var sActor = context.Actors
                .First(x => x.Name
                .Equals("Sanyi"));
            //var sRole = context.Roles.Where(x => x.ActorId == sActor.Id);
            //var sMovie = context.Movies.Where(x => x.Id == sRole.First().MovieId);

            var tabel = context.Movies
                .Include(x => x.Roles)
                .ThenInclude(x => x.Actor)
                .ToList();

            var result = context.Movies
                .Where(x => x.Roles
                .Any(r=> r.Actor == sActor));

            Console.WriteLine(string.Join("\n", result));

            var result1 = context.Actors
                .First(x => x.Name
                .Equals("Sanyi")).Roles
                .Select(x => x.Movie);

            Console.WriteLine(string.Join("\n", result1));
        }
    }
}