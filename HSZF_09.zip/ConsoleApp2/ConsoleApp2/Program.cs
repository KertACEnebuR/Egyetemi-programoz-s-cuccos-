﻿namespace ConsoleApp2
{
    internal class Program
    {
        static Random random = new Random();
        static void Main(string[] args)
        {
            Program p = new Program();
            int[] arr = new int [10000];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(0, 5000);
            }

            p.FindMax(arr, 0, arr.Length);

            Task<int> task1 = new Task<int>(() => p.FindMax(arr, 0, 5));
            Task<int> task2 = new Task<int>(() => p.FindMaxWait(arr, 0, arr.Length));

            task1.Start();
            task2.Start();

            Task.WaitAll(task1, task2);

            Console.WriteLine("Hello World!");
            Console.WriteLine("Task1: " + task1.Result);
            Console.WriteLine("Task2: " + task2.Result);

            Console.WriteLine("Tömb");
            Console.ReadLine();

            //Task[] tasks = new Task[]
            //{
            //    new Task(() => p.FindMaxConsole(arr, 0, 500)),
            //    new Task(() => p.FindMaxConsole(arr, 500, 600)),
            //    new Task(() => p.FindMaxConsole(arr, 600, 2000)),
            //    new Task(() => p.FindMaxConsole(arr, 2000, 5000)),
            //    new Task(() => p.FindMaxConsole(arr, 5000, 7000)),
            //    new Task(() => p.FindMaxConsole(arr, 7000, 10000)),
            //};



            Task[] tasks = new Task[10];
            for (int i = 0; i < 10; i++)
            {
                int j = i;
                tasks[i] = new Task(() => p
                .FindMaxConsole
                (
                    arr, 
                    j * arr.Length / 11, 
                    (j + 1) * arr.Length / 11
                ));
            }

            foreach (var task in tasks)
            {
                task.Start();
            }

            Task.WaitAll(tasks);
        }

        void FindMaxConsole(int[] arr, int from, int to)
        {
            int max = int.MinValue;
            for (int i = from; i < to; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }
            Console.WriteLine($"{from} - {to} : {max}");
        }

        int FindMax(int[] arr, int from, int to)
        {
            int max = int.MinValue;
            for (int i = from; i < to; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }
            //Console.WriteLine($"{from} - {to} : {max}");
            return max;
        }

        int FindMaxWait(int[] arr, int from, int to)
        {
            int max = int.MinValue;
            for (int i = from; i < to; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }
            Task.Delay(3000).Wait();
            //Console.WriteLine($"{from} - {to} : {max}");
            return max;
        }
    }
}
