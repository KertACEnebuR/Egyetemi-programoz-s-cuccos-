﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    enum UnitType {kg, L, pcs, packages }
}
