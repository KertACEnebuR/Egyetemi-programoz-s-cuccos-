﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    class IngredientStack
    {
        FoodIngredient[] storage;
        int pointer;

        public IngredientStack(int capacity)
        {
            this.storage = new FoodIngredient[capacity];
        }

        public void Push(FoodIngredient item)
        {
            if (pointer == storage.Length)
            {
                throw new StackFullException(this, item);
            }
            storage[pointer++] = item;
        }

        public FoodIngredient Pop()
        {
            return storage[--pointer];
        }
    }
}
