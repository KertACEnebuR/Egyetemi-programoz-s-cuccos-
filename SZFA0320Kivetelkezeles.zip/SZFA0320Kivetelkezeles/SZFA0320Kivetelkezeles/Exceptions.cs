﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    class Exceptions : Exception
    {
        public Exceptions(IngredientStack stack)
        {
            Stack = stack;
        }

        public IngredientStack Stack { get; }
    }

    class StackFullException : Exceptions
    {
        public FoodIngredient Item { get; set; }
        public StackFullException(IngredientStack stack, FoodIngredient item) : base(stack)
        {
            Item = item;
        }
    }

    class StackEmptyException : Exceptions
    {

    }
}
