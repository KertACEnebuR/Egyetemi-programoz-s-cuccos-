﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    class Program
    {
        static void Main(string[] args)
        {
            IValidator validator = new UnitTypeValidator();



            IngredientStack stack = new IngredientStack(3);

            try
            {
                stack.Push(new FoodIngredient("Foo1", 1.0, UnitType.kg, validator));
                Console.ReadLine();
                stack.Push(new FoodIngredient("Foo2", 1.7, UnitType.kg, validator));
                Console.ReadLine();
                stack.Push(new FoodIngredient("Foo3", 1.6, UnitType.kg, validator));
                Console.ReadLine();
                stack.Push(new FoodIngredient("Foo4", 1.3, UnitType.kg, validator));
            }
            catch (StackFullException)
            {
                Console.WriteLine("Megtelt a verem.");
            }
            catch (StackEmptyException)
            {
                // ...
            }
            finally
            {
                // ...
            }
        }
    }
}
