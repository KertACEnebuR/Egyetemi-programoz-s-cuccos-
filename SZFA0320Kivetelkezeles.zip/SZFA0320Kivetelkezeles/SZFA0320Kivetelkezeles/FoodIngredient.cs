﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    class FoodIngredient
    {
        public FoodIngredient(string name, double quantity, UnitType unit, IValidator validator)
        {
            validator.Validate(quantity, unit);

            Name = name;
            Quantity = quantity;
            Unit = unit;
            
        }

        public string Name { get; }
        public double Quantity { get; }
        public UnitType Unit { get; }

    }
}
