﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZFA0320Kivetelkezeles
{
    interface IValidator
    {
        void Validate(double quantity, UnitType unit);
    }

    internal class UnitTypeValidator : IValidator
    {
        public void Validate(double quantity, UnitType unit)
        {
            if (unit == UnitType.pcs || unit == UnitType.packages)
            {
                //if (!double.IsInteger(quantity))
                if (!((int)quantity == quantity))
                {
                    throw new ArgumentException($"Csak egész mennyiség lehet ennél a mértékegységnél: {unit}");
                }
            }
        }
    }
}
