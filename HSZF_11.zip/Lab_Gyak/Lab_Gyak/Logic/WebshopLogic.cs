﻿using Lab_Gyak.Models;
using Lab_Gyak.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Gyak.Logic
{
    internal class WebshopLogic
    {
        private readonly IWebshopRepository repository;
        public WebshopLogic(IWebshopRepository webshopRepository) 
        {
            this.repository = webshopRepository;
        }   

        public int GetCustomersCount()
        {
            return this.repository.GetCustomers().Count();
        }

        public int OrdersCountIn202610()
        {
            return this.repository.GetOrders()
                .Count(e => e.OrderDate.Year == 2026 && e.OrderDate.Month == 10);
        }

        public record KatGroup(string kat, int darab, double avg);

        public List<KatGroup> ProductsByCategory()
        {
            return this.repository.GetProducts()
                    .GroupBy(g => g.Category)
                    .OrderByDescending(g => g.Average(a => a.Price))
                    .Select(s => new KatGroup(s.Key, s.Count(), s.Average(a => a.Price)))
                    .ToList();
        }

        public record Koltes(string nev, int osszeg);

        public List<Koltes> GetKoltes()
        {
            return this.repository.GetCustomers()
                .Where(w => w.Orders.Any())
                .Select(s => new
                {
                    Nev = s.Name,
                    TotalSpent = s.Orders.Sum(e => e.Quantity * e.Product.Price)
                })
                .OrderByDescending(x => x.TotalSpent)
                .Select(x => new Koltes(x.Nev, x.TotalSpent))
                .ToList();
        }

        public record BestProduct(Product Product, int Quantity);

        public List<BestProduct> GetBestProduct()
        {
            var q1 = this.repository.GetOrders()
                .Select(o => new {Product = o.Product, Quantity = o.Quantity})
                .GroupBy(p => p.Product)
                .Select(g => new BestProduct(g.Key, g.Sum(s => s.Quantity)))
                .ToList();

            var max = q1.Max(e => e.Quantity);

            return q1.Where(q=> q.Quantity == max)
                .OrderByDescending(o => o.Quantity)
                .ToList();
                
        }
    }
}
