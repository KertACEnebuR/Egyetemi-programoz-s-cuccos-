﻿using Lab_Gyak.Logic;
using Lab_Gyak.Repository;

namespace Lab_Gyak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WebshopLogic logic = new WebshopLogic(new WebshopRepository());
            int count = logic.GetCustomersCount();
            Console.WriteLine(count);

            var q1 = logic.GetKoltes();
            Console.WriteLine(String.Join("\n", q1));
            Console.WriteLine();
            var q2 = logic.GetBestProduct();
            Console.WriteLine(String.Join("\n", q2));
        }
    }
}
