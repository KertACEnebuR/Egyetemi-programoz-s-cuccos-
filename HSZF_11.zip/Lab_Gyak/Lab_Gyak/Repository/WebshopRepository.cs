﻿using Lab_Gyak.Data;
using Lab_Gyak.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Gyak.Repository
{
    internal class WebshopRepository : IWebshopRepository
    {

        private readonly WebshopDbContext context;

        public WebshopRepository()
        {
            this.context = new WebshopDbContext();
        }

        public IEnumerable<Customer> GetCustomers()
        {
            return this.context.Customers.Include(e => e.Orders);
        }

        public IEnumerable<Product> GetProducts()
        {
            return this.context.Products.Include(e => e.Orders);
        }

        public IEnumerable<Order> GetOrders()
        {
            return this.context.Orders.Include(e => e.Product).Include(e => e.Customer);
        }
    }
}
