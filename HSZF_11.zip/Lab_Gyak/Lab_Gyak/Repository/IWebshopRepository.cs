﻿using Lab_Gyak.Models;

namespace Lab_Gyak.Repository
{
    internal interface IWebshopRepository
    {
        IEnumerable<Customer> GetCustomers();
        IEnumerable<Order> GetOrders();
        IEnumerable<Product> GetProducts();
    }
}