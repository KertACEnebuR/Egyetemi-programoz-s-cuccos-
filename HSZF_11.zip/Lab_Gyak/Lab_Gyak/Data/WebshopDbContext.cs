﻿using Lab_Gyak.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Gyak.Data
{
    internal class WebshopDbContext : DbContext
    {
        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<Order> Orders => Set<Order>();

        public WebshopDbContext()
        {
            this.Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=Webshopdb;Integrated Security=True;MultipleActiveResultSets=true"
                                 )
                    .UseLazyLoadingProxies();
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order>()
                        .HasOne(e => e.Customer)
                        .WithMany(c => c.Orders)
                        .HasForeignKey(e => e.CustomerId)
                        .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Order>()
                        .HasOne(e => e.Product)
                        .WithMany(c => c.Orders)
                        .HasForeignKey(e => e.ProductId)
                        .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Customer>()
                        .HasData(SeedData.Customers);
            modelBuilder.Entity<Product>()
                        .HasData(SeedData.Products);
            modelBuilder.Entity<Order>()
                        .HasData(SeedData.Orders);
        }
    }
}
