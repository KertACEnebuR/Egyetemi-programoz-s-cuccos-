﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Races
{
    class Time : IComparable<Time>
    {

        int Hour;
        int Minute;
        int Second;

        public int Hours {
            get { return Hour; }
            set
            {
                int MinHour = 0;
                int MaxHour = 3;
                if (value < MinHour || value > MaxHour)
                {
                    throw new TimeException("Az értéknek 0 és 3 között kell lennie!");
                }
            }              
        }
        public int Minutes
        {
            get { return Minute; }
            set
            {
                int MinMinute = 0;
                int MaxMinute = 59;
                if (value < MinMinute || value > MaxMinute)
                {
                    throw new TimeException("Az értéknek 0 és 59 között kell lennie!");
                }
            }
        }
        public int Seconds
        {
            get { return Second; }
            set
            {
                int Min = 0;
                int Max = 59;
                if (value < Min || value > Max)
                {
                    throw new TimeException("Az értéknek 0 és 59 között kell lennie!");
                }
            }
        }

        public Time(int hours, int minutes, int seconds)
        {
            Hour = hours;
            Minute = minutes;
            Second = seconds;
        }

        public Time(int minutes, int seconds)
            : this(0, minutes, seconds)
        {
        }

        public override string ToString()
        {
            if (Hour == 0)
            {
                return $"{Minute.ToString("00")}:{Second.ToString("00")}";
            }
            else
            {
                return $"{Hour.ToString("00")}:{Minute.ToString("00")}:{Second.ToString("00")}";
            }
        }

        public static Time Parse(string input)
        {
            string[] temp = input.Split(':');
            if (temp.Length == 2)
            {
                int minute = int.Parse(temp[0]);
                int second = int.Parse(temp[1]);
                return new Time(minute, second);
            }
            else
            {
                int hour = int.Parse(temp[0]);
                int minute = int.Parse(temp[1]);
                int second = int.Parse(temp[2]);
                return new Time(hour, minute, second);
            }

            throw new TimeException("Nem jó a formátum!");
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException();
            }
            if (!(obj is Time))
            {
                throw new ArgumentException();
            }
            Time other = obj as Time;
            return this.Hour == other.Hour && this.Minute == other.Minute && this.Second == other.Second;
        }

        private bool IncorrectValue(int value, int lowerLimit, int higherLimit)
        {
            return (value < lowerLimit || value > higherLimit);
        }

        public int CompareTo(Time other)
        {
           int thisSeconds = this.Hour * 3600 + this.Minute * 60 + this.Second;
           int otherSeconds = other.Hour * 3600 + other.Minute * 60 + other.Second;
           return thisSeconds.CompareTo(otherSeconds);
        }
    }
}
