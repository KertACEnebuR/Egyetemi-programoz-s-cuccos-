﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Races
{
    class RunnerWithTime : IComparable<RunnerWithTime>
    {
        public string Name { get; private set; }
        public Time Time { get; private set; }

        public static RunnerWithTime Parse(string input)
        {
            string[] data = input.Split(',');
            string name = data[0];
            Time time = Time.Parse(data[1]);
            RunnerWithTime runner = new RunnerWithTime();
            runner.Name = name;
            runner.Time = time;
            return runner;
        }

        public int CompareTo(RunnerWithTime other)
        {
            if (this.Time.Equals(other.Time))
            {
                return this.Name.CompareTo(other.Name);
            }
            return this.Time.CompareTo(other.Time);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException();
            }
            if (!(obj is RunnerWithTime))
            {
                throw new ArgumentException();
            }
            RunnerWithTime other = obj as RunnerWithTime;
            return this.Name.Equals(other.Name) && this.Time.Equals(other.Time);
        }
        public override string ToString()
        {
            return $"{Name} ({Time})";
        }
    }
}
