﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Races
{
    class RaceResults
    {
        RunnerWithTime[] data;
        //int[] data;
        private bool IsSorted()
        {
            for (int i = 0; i < data.Length - 1; i++)
            {
                if (data[i].CompareTo(data[i+1]) > 0)
                {
                    return false;
                }
            }
            return true;
        }

        public int BinarySearch(RunnerWithTime value)
        {
            int left = 0;
            int right = data.Length - 1;

            while (left <= right)
            {
                int center = (left + right) / 2;

                if (data[center].CompareTo(value) == 0)
                {
                    return center;
                }
                if (data[center].CompareTo(value) < 0)
                {
                    left = center + 1;
                }
                if (data[center].CompareTo(value) > 0)
                {
                    right = center - 1;
                }
            }
            return -1;
        }

        public int[] Intersection(int[] a, int[] b)
        {
            int i = 0;
            int j = 0;
            int count = 0;

            //int[] result = new int[Math.Min(a.Length, b.Length)];
            //List<RunnerWithTime> temp = new List<RunnerWithTime>();
            List<int> temp = new List<int>();

            while (i < a.Length && j < b.Length)
            {
                if (a[i].CompareTo(b[j]) < 0)
                {
                    i++;
                }
                if (a[i].CompareTo(b[j]) > 0)
                {
                    j++;
                }
                if (a[i].CompareTo(b[j]) == 0)
                {
                    temp.Add(a[i]);
                    i++;
                    j++;
                }

                int[] result = temp.ToArray();

                return result;
            }
        }
    }
}
