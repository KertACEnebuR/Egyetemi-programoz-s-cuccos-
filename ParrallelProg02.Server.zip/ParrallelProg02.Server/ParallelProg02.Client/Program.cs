﻿using System.Diagnostics;

namespace ParallelProg02.Client
{
    internal class Program
    {
        static readonly object LockObject = new object();
        static readonly string port = "5224";
        static async Task Main(string[] args)
        {
            var client = new Client($"http://localhost:{port}", new HttpClient());

            var sw = Stopwatch.StartNew();
            await client.Movie_GetMoviesAsync();
            sw.Stop();
            Console.WriteLine($"Time taken: {sw.ElapsedMilliseconds} ms");

            Task[] tasks = new Task[100];
            ConsoleColor[] colors = new ConsoleColor[]
            {
                ConsoleColor.Red,
                ConsoleColor.Green,
                ConsoleColor.Blue,
                ConsoleColor.Yellow,
                ConsoleColor.Magenta
            };

            for (int i = 0; i < 100; i++) 
            {
                int id = i;
                ConsoleColor color = colors[i % colors.Length];
                tasks[i] = Task.Run(() => Avg(client, color, id));
            }
            Task.WaitAll(tasks);
            ;
        }

        static void Avg(Client client, ConsoleColor color, int id)
        {
            var avg = client.Movie_GetMoviesAsync().Result.Average(a => a.Rating);
            lock (LockObject)
            {
                lock (LockObject) 
                {
                    Console.BackgroundColor = color;
                    Console.WriteLine($"Average rating: {avg}, Id {id}");
                    Console.ResetColor();
                } 
            }
        }
    }
}
