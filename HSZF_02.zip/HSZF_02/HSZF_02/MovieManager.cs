﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HSZF_02
{
    internal class MovieManager
    {
        private List<Movie> movies;
        private readonly string filePath = "movies.json";

        public event EventHandler<string> Event;
        JsonSerializerOptions options = new JsonSerializerOptions
        {
            WriteIndented = true,
            IncludeFields = false,
        };

        public MovieManager()
        {
            //LoadMovies();
        }

        public void LoadMovies()
        {
            if (File.Exists(filePath))
            {
                var temp = JsonSerializer
                    .Deserialize<List<Movie>>(File.ReadAllText(filePath), options);
                Event?.Invoke(this, "Load OK!");
            }
            if (movies == null)
            {
                movies = new List<Movie>();
            }
        }

        public void AddMovie(Movie movie)
        {
            movies.Add(movie);
        }

        public void AddMovie(string title, int minutes, DateTime? releaseDate)
        {
            Movie movie = new Movie(title, minutes, releaseDate);
            movies.Add(movie);
        }

        public void SaveMovies()
        {
            File.WriteAllText(filePath, JsonSerializer.Serialize(movies, options));
            Event?.Invoke(this, "Save OK!");
        }
        public void ListMovies()
        {
            string output = "Movies: \n";
            foreach (var movie in movies)
            {
                output += $"{movie}\n";
            }
            Console.WriteLine(output);
        }

        public bool IsAnyMovieLongerThan(int minutes)
        {
            return movies
                .Any(m => m.Minutes > minutes);
        }

        public Movie LongerThan(int min)
        {
            return movies
                .FirstOrDefault(x => x.Minutes > min);
        }

        public string TitleLongerThan(int min)
        {
            //.FirstOrDefault(x => x.Minutes > min).Title;
            var temp = movies.Select(x => new
            {
                SelectedTitle = x.Title,
                SelectedMinutes = x.Minutes
            });

            return temp
                .FirstOrDefault(x => x.SelectedMinutes > min).SelectedTitle;
        }

        public void A()
        {
            var a = movies
                .All(x => x.ReleaseDate?.Date.Year > 2000 && x.ReleaseDate?.Date.Year < 2010);
            var b = movies
                .Where(x => x.ReleaseDate?.Date.Year > 2000 && x.ReleaseDate?.Date.Year < 2010).Select(x => new
                {
                    SelectedTitle = x.Title
                })
                .All(x => x.SelectedTitle.Contains("a") || x.SelectedTitle.Contains("b"));
        }

    }
}
