﻿using HSZF_02;
using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string inputTitle;
            int inputMinutes;
            DateTime? inputReleaseDate = null;
            MovieManager movieManager = new MovieManager();
            movieManager.Event += MovieManager_Event;
            movieManager.LoadMovies();
            while (true) 
            {
                Console.WriteLine("Kilépsz?");
                inputTitle = Console.ReadLine();
                if (inputTitle == "exit")
                {
                    break;
                }
                Console.WriteLine("Kérem a film címét: ");
                inputTitle = Console.ReadLine();
                Console.WriteLine("Kérem a film hosszát percekben: ");
                inputMinutes = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Kérem a megjelenési dátumot (YYYY.MM.DD): ");
                inputReleaseDate = Convert.ToDateTime(Console.ReadLine());
                movieManager.AddMovie(inputTitle, inputMinutes, inputReleaseDate);
            }
            movieManager.ListMovies();

            movieManager.SaveMovies();

        }

        private static void MovieManager_Event(object? sender, string e)
        {
            Console.WriteLine(e);
        }
    }
}
