﻿namespace HSZF
{
    using System.Text;
    using System.Text.Json;
    using Data;
    using Data.Entities;
    internal class Program
    {
        static void Main(string[] args)
        {
            MovieManager movieManager = new MovieManager();
            movieManager.ReadFile("Data\\Saves\\Movies.json");

            Console.WriteLine(string.Join("\n", movieManager.GetMovies()));

            MovieManager movies = new MovieManager();

            var topmovies = movies.TopRatedMovies();

            Console.WriteLine("\n1. Melyik filmnek van a legjobb értékelése?");
            foreach (var item in topmovies)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("\n2. Melyik filmek rendezője egy adott rendező?");
            var directorMovies = movies.DirectorMovies("Christopher Nolan");

            foreach (var movie in directorMovies)
            {
                Console.WriteLine(movie.Title);
            }

            var moviesRDate = movies.TitleWithReleaseDate();

            Console.WriteLine(movies);

            bool better = movies.IsBetterThan(5.0);

            Console.WriteLine(better);

            var bestMovie = movies.BestMovieAtTime(
                new DateTime(2000, 1, 1),
                new DateTime(2020, 1, 1));

            Console.WriteLine(bestMovie?.Title);

            var worstMovies = movies.ThreeWorstMovies();

            foreach (var movie in worstMovies)
            {
                Console.WriteLine(movie.Title);
            }

            bool exists = movies.MovieWithExactRating(8.5);
        }
    }
}
