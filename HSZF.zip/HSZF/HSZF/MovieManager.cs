﻿using HSZF.Data;
using HSZF.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HSZF
{
    public class MovieManager
    {
        JsonSerializerOptions options;
        MovieContext context;
        public MovieManager()
        {
            options = new JsonSerializerOptions
            {
                ReferenceHandler = ReferenceHandler.Preserve,
                PropertyNameCaseInsensitive = true,
                WriteIndented = true,
                IncludeFields = false,
                MaxDepth = 1024
            };
            context = new MovieContext();
        }

        public void ReadFile(string path = "movies.json")
        {
            //json fájból beolvassa a 100 filmet, hogy tudjatok min lekérdezni
            context.ChangeTracker.LazyLoadingEnabled = false;
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            var loadedMovies = JsonSerializer.Deserialize<List<Movie>>(File.ReadAllText(path), options);
           
            foreach (var movie in loadedMovies) //ez azért kell, mert az ID nem érdekes, majd a nav property megoldja
            {
                movie.Id = 0;
                movie.DirectorId = 0;
                movie.Director.Id = 0;

                foreach (var role in movie.Roles)
                {
                    role.Id = 0;
                    role.MovieId = 0;
                    role.ActorId = 0;
                    role.Actor.Id = 0;
                }
            }

            context.Movies.AddRange(loadedMovies);

            context.SaveChanges();
            context.ChangeTracker.LazyLoadingEnabled = true;
        }

        public void SaveFile(string path)
        {
            var movies = context.Movies
                .Include(m => m.Director)
                .Include(m => m.Roles).ThenInclude(r => r.Actor)
                .AsNoTracking()
                .ToList();

            File.WriteAllText(path, JsonSerializer.Serialize(movies, options));
        }

        public List<Movie> GetMovies()
        {
            return this.context.Movies.ToList();
        }

        //feladat.txt-ben leírt feladatokat itt kellene megoldani

        public List<Movie> TopRatedMovies()
        {
            var HighestRating = context.Movies.Max(x => x.Rating);

            return this.context.Movies
                .Where(x => x.Rating == HighestRating)
                .ToList();
        }

        public List<Movie> DirectorMovies(string directorName)
        {
            return this.context.Movies
                .Include(x => x.Director)
                .Where(x => x.Director.Name == directorName)
                .ToList();
        }

        public object TitleWithReleaseDate()
        {
            return context.Movies
                .Select(x => new
                {
                    x.Title,
                    x.ReleaseDate
                })
                .ToList();
        }

        public bool IsBetterThan(double minRating)
        {
            return this.context.Movies
                .All(x => x.Rating > minRating);
        }

        public Movie BestMovieAtTime(DateTime from, DateTime to)
        {
            return this.context.Movies.Where(x => x.ReleaseDate > from && x.ReleaseDate < to).OrderByDescending(y => y.Rating).FirstOrDefault();
        }

        public List<Movie> ThreeWorstMovies()
        {
            return this.context.Movies
                .OrderBy(x => x.Rating)
                .Take(3)
                .ToList();
        }

        public bool MovieWithExactRating(double rating)
        {
            var movie = context.Movies
                .SingleOrDefault(x => x.Rating == rating);

            return movie != null;
        }

        public List<Movie> BetterThanAverage()
        {
            var average = context.Movies.Average(y => y.Rating);
            return context.Movies.Where(y => y.Rating > average).ToList();
        }

        public bool NoRoles()
        {
            return context.Movies.Include(y => y.Roles).Any(s => s.Roles == null);
        }

        //
        public Actor ActorWithMostRoles()
        {
            var temp = context.Actors
                .Include(y => y.Roles)
                .Select(y => new { 
                    AName = y.Name,
                    RolesCount = y.Roles.Where(e => e.Id == e.ActorId).Count()
            });

            return (Actor)temp;
        }

        public int ActorCountInHighestRatedMovie()
        {
            var bestRating = context.Movies.Max(a => a.Rating);
            return context.Movies.Include(y => y.Actors).Where(y => y.Rating == bestRating).Count();
        }

        public int ActorWorstAndBestMovie(string actorName)
        {
            return 0;
        }

        public bool SameNameActor()
        {
            return context.Actors.Any(a => a.Name == a.Name);
        }

        public string MostMoviesDirector()
        {
            return context.Directors
                .Select(y => new
            {
                Name = y.Name,
                MoviesCount = y.Movies.Count()
            })
            .OrderBy(e => e.MoviesCount)
            .First().Name;
        }

        //public List<Movie> DirectorRatingGroupBy()
        //{
        //    return context.Movies
        //        .Include(y => y.Director)
        //        .OrderByDescending(e => e.Rating)
        //        .GroupBy(y => y.Director.Name)
        //        .ToList();
        //}
    }
}
