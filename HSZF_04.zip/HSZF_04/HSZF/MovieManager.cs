﻿using HSZF.Data;
using HSZF.Data.Entities;
using HSZF.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HSZF
{
    public class MovieManager
    {
        JsonSerializerOptions options;
        IMovieRepository context;
        public MovieManager(IMovieRepository context)
        {    
            this.context = context;
        }

        public void ReadFile(string path = "movies.json")
        {
            this.context.Load(path);
        }

        public void SaveFile(string path)
        {
            this.context.Save(path);
        }

        public List<Movie> GetMovies()
        {
            return this.context.Movies.ToList();
        }

        //feladat.txt-ben leírt feladatokat itt kellene megoldani


        public List<Movie> GetBestMovies() 
        {
            var maxRating = context.Movies
                .Max(m => m.Rating);

            return this.context.Movies
                .Where(x => x.Rating == maxRating)
                .ToList();
        }

        public List<Movie> GetMoviesOfDirector(string directorName)
        {
            return this.context.Movies
                .Where(x => x.Director.Name == directorName)
                .ToList();
        }

        public List<Tuple<string, DateTime?>> GetMovieNameAndReleaseDate()
        {
            return this.context.Movies
                .Select(x => Tuple.Create( x.Title, x.ReleaseDate ))
                .ToList();
        }

        public bool IsBetterThan(double minRating)
        {
            return this.context.Movies.All(x=> x.Rating > minRating);
        }

        public Movie? BestMovieBetween(DateTime from, DateTime to)
        {
            return this.context.Movies
                .Where(x => x.ReleaseDate >= from && x.ReleaseDate <= to)
                .MaxBy(x => x.Rating);
        }
    }
}
