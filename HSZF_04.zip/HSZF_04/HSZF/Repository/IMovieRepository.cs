﻿using HSZF.Data.Entities;

namespace HSZF.Repository
{
    public interface IMovieRepository
    {
        IEnumerable<Movie> Movies { get; }

        void Create(Movie movie);
        void Delete(Movie movie);
        IEnumerable<Movie> Read();
        void Update(Movie movie);

        void Load(string path);
        void Save(string path);
    }
}