﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KerteszRuben_Y2T1N0_ZH1
{
    public enum PlacementMethod { Arbitrary, Horizontal, Vertical }
    public abstract class Parcel : IDeliverable, IComparable<Parcel>
    {
        public PlacementMethod Method { get; protected set; }

        protected Parcel(PlacementMethod method, int weight, string address)
        {
            Method = method;
            Weight = weight;
            Address = address;
        }

        public Parcel(int weight, string address)
        {
            Weight = weight;
            Address = address;
        }

        public int Weight { get; private set; }
        public string Address { get; private set; }
        public abstract double CalculatePrice(bool fromLocker);


        public override string ToString()
        {
            return $"Címzett: {Address} / Elhelyezési mód: {Method} / Tömeg:{Weight} g";
        }

        public int CompareTo(Parcel other)
        {
            if (other == null) return 1;

            if (this.Weight < other.Weight)
                return -1;

            if (this.Weight > other.Weight)
                return 1;

            return this.Address.CompareTo(other.Address);
        }
    }
}
