﻿namespace KerteszRuben_Y2T1N0_ZH1
{
    public class Envelope : IDeliverable
    {
        string Description;

        public Envelope(string description, int weight, string address)
        {
            Description = description;
            Weight = weight;
            Address = address;
        }

        public int Weight { get; private set; }
        public string Address { get; private set; }

        public double CalculatePrice(bool fromLocker)
        {
            if (Weight < 50)
            {
                return 200;
            }
            if (Weight < 500)
            {
                return 400;
            }
            if (Weight <= 2000)
            {
                return 1000;
            }
            throw new OverweightException();
        }

        public override string ToString()
        {
            return $"Címzett: {Address} / Leírás: {Description} / Tömeg:{Weight} g";
        }
    }
}
