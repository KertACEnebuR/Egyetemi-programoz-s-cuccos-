﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KerteszRuben_Y2T1N0_ZH1
{
    public interface IDeliverable
    {
        int Weight { get; }
        string Address { get; }
        double CalculatePrice(bool fromLocker);
    }
    class Program
    {

        static void Main(string[] args)
        {
        }
    }
}
