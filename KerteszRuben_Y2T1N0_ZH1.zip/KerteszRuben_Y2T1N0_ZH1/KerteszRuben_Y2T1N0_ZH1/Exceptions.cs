﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KerteszRuben_Y2T1N0_ZH1
{
    public class OverweightException : Exception
    {
    }
    public class DeliveryException : Exception
    {
        public DeliveryException(string message) : base(message)
        {
        }
    }

    public class IncorrectOrientationException : DeliveryException
    {
        public Parcel Parcel { get; private set; }

        public IncorrectOrientationException(string message, Parcel parcel)
            : base(message)
        {
            Parcel = parcel;
        }
    }
}
