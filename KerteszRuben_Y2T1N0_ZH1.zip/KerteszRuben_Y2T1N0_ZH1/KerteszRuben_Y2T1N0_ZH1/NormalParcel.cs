﻿using System;

namespace KerteszRuben_Y2T1N0_ZH1
{
    class NormalParcel : Parcel
    {
        private bool fromLocker;
        private static Random rnd = new Random();

        public NormalParcel(int weight, string address): base(weight, address)
        {
            Method = (PlacementMethod)rnd.Next(0, 3);
        }

        public override double CalculatePrice(bool fromLocker)
        {
            int price = 500 + Weight;

            if (fromLocker)
            {
                price -= 250;
            }

            return price;
        }
    }
}