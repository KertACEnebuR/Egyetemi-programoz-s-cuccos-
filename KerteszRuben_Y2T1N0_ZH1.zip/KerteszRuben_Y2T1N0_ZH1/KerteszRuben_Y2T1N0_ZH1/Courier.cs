﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KerteszRuben_Y2T1N0_ZH1
{
    public class Courier 
    {
        private IDeliverable[] parcels;
        private int parcelsLength;
        private int currentIndex = 0;
        public double WeightSum { get; private set; }

        public Courier(int capacity)
        {
            this.parcelsLength = capacity;
            parcels = new IDeliverable[capacity];
        }
    }
}
