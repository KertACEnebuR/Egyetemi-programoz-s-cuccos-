﻿using KerteszRuben_Y2T1N0_ZH1;
using System;

public class FragileParcel : Parcel
{
    public FragileParcel(int weight, string address, PlacementMethod method)
        : base(method, weight, address)
    {
        if (method == PlacementMethod.Arbitrary)
        {
            throw new IncorrectOrientationException(
                "Törékeny csomag nem lehet Arbitrary elhelyezésű!",
                this
            );
        }
    }

    public override double CalculatePrice(bool fromLocker)
    {
        if (fromLocker)
        {
            throw new DeliveryException(
                "Törékeny csomag nem adható fel automatából!"
            );
        }

        return 1000 + Weight * 2;
    }
}