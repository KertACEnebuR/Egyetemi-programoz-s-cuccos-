using NUnit.Framework;
using KerteszRuben_Y2T1N0_ZH1;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            var env = new Envelope("Leiras", 100, "Cim");

            double price = env.CalculatePrice(false);

            Assert.AreEqual(400, price);
        }
        public void Test2()
        {
            var env = new Envelope("Leiras", 100, "Cim");

            double price = env.CalculatePrice(true);

            Assert.AreEqual(400, price);
        }
    }
}